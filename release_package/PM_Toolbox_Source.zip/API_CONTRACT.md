# PM TOOLBOX — 前后端接口契约

> 本文档定义前后端所有 API 的接口规范。前后端各自的 agent 都必须遵守此契约。
>
> **修改此文档需前后端双方确认。**

---

## 最后更新

- 版本：v1.0
- 更新时间：2026-05-27
- 状态：✅ 已确认

---

## 1. 通用规范

### 1.1 基础信息

| 项 | 值 |
|----|----|
| 协议 | HTTP |
| 主机 | 127.0.0.1 |
| 端口 | 8000（uvicorn 默认） |
| API 前缀 | `/api` |
| 静态文件 | `/` 托管前端 dist/ 目录 |

### 1.2 请求/响应格式

**请求**：
- GET：查询参数在 URL 中
- POST/PUT：JSON body，`Content-Type: application/json`
- 文件上传：`multipart/form-data`

**响应**：统一包装格式

```json
{
  "success": true,
  "data": {},
  "message": null
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| success | boolean | 操作是否成功 |
| data | any | 成功时的返回数据 |
| message | string \| null | 失败时的错误信息，成功时为 null |

### 1.3 HTTP 状态码

| 状态码 | 含义 | 场景 |
|--------|------|------|
| 200 | 成功 | 正常返回 |
| 400 | 参数错误 | 缺少必填字段、格式不正确 |
| 404 | 资源不存在 | 问题 ID 不存在 |
| 500 | 服务器内部错误 | 未捕获异常 |

### 1.4 分页规范

GET 列表接口统一分页参数：

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| page | int | 1 | 页码，从 1 开始 |
| size | int | 20 | 每页条数，最大 100 |

分页响应格式：

```json
{
  "success": true,
  "data": {
    "items": [],
    "total": 142,
    "page": 1,
    "size": 20
  }
}
```

---

## 2. 问题追踪 API

### 2.1 获取问题列表

```
GET /api/issues?page=1&size=20&priority=P0&status=open&department=车身钣金
```

**请求参数（Query）：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | int | 否 | 页码，默认 1 |
| size | int | 否 | 每页条数，默认 20 |
| priority | string | 否 | 筛选优先级：P0/P1/P2/P3 |
| status | string | 否 | 筛选状态：open/in_progress/resolved/closed |
| department | string | 否 | 筛选部门 |

**响应：**

```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "ISS-2024-001",
        "priority": "P0",
        "component": "前保险杠",
        "description": "前保险杠与翼子板间隙超差 2.5mm",
        "department": "车身钣金",
        "status": "open",
        "assignee": "张伟",
        "created_at": "2024-01-15T00:00:00",
        "updated_at": "2024-01-15T00:00:00"
      }
    ],
    "total": 142,
    "page": 1,
    "size": 20
  }
}
```

### 2.2 创建问题

```
POST /api/issues
```

**请求体：**

```json
{
  "priority": "P1",
  "component": "仪表板",
  "description": "仪表板表面缩痕",
  "department": "内外饰件",
  "assignee": "李芳"
}
```

**响应：**

```json
{
  "success": true,
  "data": {
    "id": "ISS-2024-015",
    "priority": "P1",
    "component": "仪表板",
    "description": "仪表板表面缩痕",
    "department": "内外饰件",
    "status": "open",
    "assignee": "李芳",
    "created_at": "2024-01-15T10:30:00",
    "updated_at": "2024-01-15T10:30:00"
  }
}
```

### 2.3 更新问题

```
PUT /api/issues/{id}
```

**请求体：**

```json
{
  "status": "resolved",
  "assignee": "赵敏"
}
```

**响应：**

```json
{
  "success": true,
  "data": {
    "id": "ISS-2024-001",
    "status": "resolved",
    "assignee": "赵敏",
    "updated_at": "2024-01-15T14:00:00"
  }
}
```

### 2.4 删除问题

```
DELETE /api/issues/{id}
```

**响应：**

```json
{
  "success": true,
  "data": null
}
```

### 2.5 问题统计（KPI）

```
GET /api/issues/stats
```

**响应：**

```json
{
  "success": true,
  "data": {
    "total_open": 142,
    "new_this_week": 23,
    "closed_this_week": 18,
    "high_risk_count": 7,
    "department_stats": [
      { "department": "车身钣金", "closed_rate": 78, "total_issues": 56 },
      { "department": "内外饰件", "closed_rate": 65, "total_issues": 43 },
      { "department": "灯具", "closed_rate": 82, "total_issues": 38 }
    ],
    "trend": [
      { "date": "01-01", "count": 8 },
      { "date": "01-02", "count": 12 }
    ]
  }
}
```

---

## 3. Excel 工具 API

### 3.1 多文件合并（多 Sheet）

```
POST /api/excel/merge
Content-Type: multipart/form-data
```

**请求参数（Form）：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| files | File[] | 是 | 多个 Excel 文件，字段名 "files" |

**响应：**

```json
{
  "success": true,
  "data": {
    "file_path": "./temp/merged_20240115_103000.xlsx",
    "file_name": "merged_20240115_103000.xlsx",
    "sheet_count": 5
  }
}
```

### 3.2 同结构表格纵向拼接

```
POST /api/excel/merge-same
Content-Type: multipart/form-data
```

**请求参数（Form）：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| files | File[] | 是 | 多个同结构 Excel 文件 |
| header_row | int | 否 | 表头行号（0-based），默认 0 |

**响应：**

```json
{
  "success": true,
  "data": {
    "file_path": "./temp/merged_same_20240115_103000.xlsx",
    "file_name": "merged_same_20240115_103000.xlsx",
    "row_count": 150
  }
}
```

### 3.3 批量正则改名

```
POST /api/excel/rename
Content-Type: application/json
```

**请求体：**

```json
{
  "folder": "C:/Users/PM/Documents/交付物",
  "pattern": "(.*)_old(.*)",
  "replacement": "\\1_new\\2"
}
```

**响应：**

```json
{
  "success": true,
  "data": {
    "renamed_files": [
      { "old": "报告_old_v1.xlsx", "new": "报告_new_v1.xlsx" }
    ],
    "skipped_files": [],
    "count": 12
  }
}
```

---

## 4. PPT 生成 API

### 4.1 获取模板列表

```
GET /api/ppt/templates
```

**响应：**

```json
{
  "success": true,
  "data": [
    {
      "id": "weekly_report",
      "name": "项目周报",
      "description": "周度问题统计与进度汇报",
      "slides": 8
    },
    {
      "id": "deliverable",
      "name": "交付物报告",
      "description": "单个交付物状态跟踪",
      "slides": 5
    }
  ]
}
```

### 4.2 生成周报 PPT

```
POST /api/ppt/weekly
Content-Type: application/json
```

**请求体：**

```json
{
  "week_start": "2024-01-15",
  "project_name": "某车型车身开发",
  "author": "项目管理部"
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| week_start | string | 否 | 周起始日期 "YYYY-MM-DD"，默认本周一 |
| project_name | string | 否 | 项目名称 |
| author | string | 否 | 报告人 |

**响应：**

```json
{
  "success": true,
  "data": {
    "file_path": "./templates/output/weekly_report_20240115_103000.pptx",
    "file_name": "weekly_report_20240115_103000.pptx",
    "week_date": "01/15-01/21"
  }
}
```

### 4.3 生成交付物报告 PPT

```
POST /api/ppt/deliverable
Content-Type: application/json
```

**请求体：**

```json
{
  "deliverable_name": "前保险杠总成",
  "responsible": "车身钣金组"
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| deliverable_name | string | 是 | 交付物名称 |
| responsible | string | 否 | 负责部门 |

**响应：**

```json
{
  "success": true,
  "data": {
    "file_path": "./templates/output/deliverable_20240115_103000.pptx",
    "file_name": "deliverable_20240115_103000.pptx"
  }
}
```

---

## 5. 爬虫 API

### 5.1 抓取页面内容

```
POST /api/crawler/fetch
Content-Type: application/json
```

**请求体：**

```json
{
  "url": "http://ewo.company.com/page"
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| url | string | 是 | 目标页面 URL |

**响应：**

```json
{
  "success": true,
  "data": {
    "url": "http://ewo.company.com/page",
    "title": "页面标题",
    "content": "HTML 内容（已简化）",
    "browser_used": "chrome"
  }
}
```

### 5.2 提取页面表格

```
POST /api/crawler/table
Content-Type: application/json
```

**请求体：**

```json
{
  "url": "http://ewo.company.com/page",
  "xpath": "//table[@id='data']"
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| url | string | 是 | 目标页面 URL |
| xpath | string | 否 | 表格 xpath，默认 "//table" |

**响应：**

```json
{
  "success": true,
  "data": {
    "headers": ["列1", "列2", "列3"],
    "rows": [
      ["值1", "值2", "值3"]
    ],
    "row_count": 50
  }
}
```

---

## 6. 飞书邮件 API

### 6.1 获取邮件列表

```
GET /api/feishu/mails?category=&is_read=&page=1&size=20
```

**请求参数（Query）：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| category | string | 否 | 筛选分类 |
| is_read | int | 否 | 0=未读 1=已读 |
| page | int | 否 | 默认 1 |
| size | int | 否 | 默认 20 |

**响应：**

```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "M001",
        "sender": "李明 - 车身工程部",
        "subject": "【交付物】车身钣金 DV 试验报告",
        "preview": "附件为车身钣金 DV 试验报告...",
        "date": "今天 09:30",
        "is_read": false,
        "is_starred": true,
        "has_attachment": true,
        "category": "交付物"
      }
    ],
    "total": 7
  }
}
```

### 6.2 同步邮件

```
POST /api/feishu/sync
```

**说明：** 触发邮件同步，后端通过 Edge WebDriver 抓取飞书最新邮件。

**响应：**

```json
{
  "success": true,
  "data": {
    "synced_count": 3,
    "new_count": 1
  }
}
```

### 6.3 获取待办列表

```
GET /api/feishu/todos
```

**响应：**

```json
{
  "success": true,
  "data": [
    {
      "id": "T001",
      "content": "审核车身钣金 DV 试验报告",
      "source": "李明邮件",
      "deadline": "今天",
      "completed": false
    }
  ]
}
```

### 6.4 切换待办状态

```
POST /api/feishu/todo-toggle
Content-Type: application/json
```

**请求体：**

```json
{
  "id": "T001"
}
```

**响应：**

```json
{
  "success": true,
  "data": {
    "id": "T001",
    "completed": true
  }
}
```

---

## 7. 文件下载

所有生成文件（Excel、PPT）通过统一下载端点获取：

```
GET /api/download?path={file_path}
```

**请求参数（Query）：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| path | string | 是 | 服务器上的文件路径 |

**响应：** 二进制文件流，`Content-Disposition: attachment`

**注意：** path 参数做安全检查，只能访问 output/ 和 temp/ 目录下的文件。

---

## 8. 变更记录

| 版本 | 日期 | 变更内容 | 确认 |
|------|------|----------|------|
| v1.0 | 2026-05-27 | 初始版本 | ✅ |
