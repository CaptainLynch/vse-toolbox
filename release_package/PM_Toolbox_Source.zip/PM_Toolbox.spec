# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['/mnt/project/vse-toolbox/backend/main.py'],
    pathex=[],
    binaries=[],
    datas=[('/mnt/project/vse-toolbox/backend/dist', 'dist'), ('/mnt/project/vse-toolbox/backend/templates/master/deliverable_master.pptx', 'templates/master'), ('/mnt/project/vse-toolbox/backend/templates/master/weekly_report_master.pptx', 'templates/master'), ('/mnt/project/vse-toolbox/backend/templates/config/deliverable_map.json', 'templates/config'), ('/mnt/project/vse-toolbox/backend/templates/config/weekly_map.json', 'templates/config')],
    hiddenimports=['fastapi', 'starlette', 'uvicorn', 'uvicorn.logging', 'uvicorn.lifespan', 'uvicorn.protocols', 'uvicorn.protocols.http', 'uvicorn.protocols.websockets', 'pydantic', 'pydantic.deprecated', 'openpyxl', 'openpyxl.cell', 'openpyxl.styles', 'pandas', 'pptx', 'pptx.util', 'pptx.dml', 'pptx.dml.color', 'matplotlib', 'matplotlib.backends', 'matplotlib.backends.backend_agg', 'matplotlib.backends.backend_svg', 'numpy', 'selenium', 'selenium.webdriver', 'selenium.webdriver.chrome', 'selenium.webdriver.edge', 'selenium.webdriver.common', 'api', 'api.issues', 'api.excel', 'api.crawler', 'api.ppt', 'api.feishu', 'api.milestones', 'services', 'services.db', 'services.excel_service', 'services.ppt_service', 'services.crawler_service', 'services.feishu_service', 'models', 'models.schemas'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'IPython', 'jupyter', 'notebook', 'PyQt5', 'PySide2', 'wx', 'test', 'setuptools'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='PM_Toolbox',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
