#!/usr/bin/env python3
"""PM TOOLBOX — PyInstaller 打包脚本。

将后端 FastAPI 服务打包为独立 .exe 文件，可在无 Python 环境的 Windows 电脑上运行。

用法:
    python build.py          # 执行打包
    python build.py --clean  # 清理旧的 build/dist 后重新打包
"""

import shutil
import sys
from pathlib import Path

import PyInstaller.__main__

ROOT = Path(__file__).parent
BACKEND = ROOT / "backend"
DIST = ROOT / "dist_pyinstaller"
BUILD = ROOT / "build_pyinstaller"

# ——————————————————————————————————————————————
# 入口脚本
# ——————————————————————————————————————————————
ENTRY = str(BACKEND / "main.py")

# ——————————————————————————————————————————————
# 应用名称
# ——————————————————————————————————————————————
APP_NAME = "PM_Toolbox"

# ——————————————————————————————————————————————
# Hidden imports（防止 PyInstaller 遗漏的隐式依赖）
# ——————————————————————————————————————————————
HIDDEN_IMPORTS = [
    # FastAPI / Starlette
    "fastapi",
    "starlette",
    "uvicorn",
    "uvicorn.logging",
    "uvicorn.lifespan",
    "uvicorn.protocols",
    "uvicorn.protocols.http",
    "uvicorn.protocols.websockets",
    # Pydantic
    "pydantic",
    "pydantic.deprecated",
    # Excel
    "openpyxl",
    "openpyxl.cell",
    "openpyxl.styles",
    "pandas",
    # PPT
    "pptx",
    "pptx.util",
    "pptx.dml",
    "pptx.dml.color",
    # matplotlib
    "matplotlib",
    "matplotlib.backends",
    "matplotlib.backends.backend_agg",
    "matplotlib.backends.backend_svg",
    "numpy",
    # selenium
    "selenium",
    "selenium.webdriver",
    "selenium.webdriver.chrome",
    "selenium.webdriver.edge",
    "selenium.webdriver.common",
    # 项目内部模块
    "api",
    "api.issues",
    "api.excel",
    "api.crawler",
    "api.ppt",
    "api.feishu",
    "api.milestones",
    "services",
    "services.db",
    "services.excel_service",
    "services.ppt_service",
    "services.crawler_service",
    "services.feishu_service",
    "models",
    "models.schemas",
]

# ——————————————————————————————————————————————
# 数据文件（打包进 exe，通过 sys._MEIPASS 访问）
# ——————————————————————————————————————————————
def _collect_add_data():
    """收集需要打包进 exe 的数据文件，返回 PyInstaller --add-data 参数列表。"""
    add_data = []

    # 前端静态文件（如果存在）
    frontend_dist = BACKEND / "dist"
    if frontend_dist.exists() and any(frontend_dist.iterdir()):
        add_data.append((str(frontend_dist), "dist"))

    # PPT 模板
    templates = BACKEND / "templates"
    if templates.exists():
        # 打包 master/ 和 config/，排除 output/
        for sub in ["master", "config"]:
            sub_path = templates / sub
            if sub_path.exists():
                for f in sub_path.iterdir():
                    if f.is_file():
                        add_data.append((str(f), f"templates/{sub}"))

    # WebDriver（如果存在）
    drivers = BACKEND / "drivers"
    if drivers.exists():
        for f in drivers.iterdir():
            if f.is_file():
                add_data.append((str(f), f"drivers/{f.name}"))

    return add_data


def clean():
    """清理构建产物。"""
    for d in [DIST, BUILD]:
        if d.exists():
            shutil.rmtree(d)
            print(f"  removed {d}")
    spec_file = ROOT / f"{APP_NAME}.spec"
    if spec_file.exists():
        spec_file.unlink()
        print(f"  removed {spec_file}")


def build():
    """执行 PyInstaller 打包。"""
    DIST.mkdir(parents=True, exist_ok=True)

    add_data = _collect_add_data()
    print(f"Data files to bundle: {len(add_data)} entries")
    for src, dst in add_data:
        print(f"  {src} -> {dst}")

    args = [
        ENTRY,
        "--name", APP_NAME,
        "--onefile",
        "--console",
        "--clean",
        "--noconfirm",
        f"--distpath={DIST}",
        f"--workpath={BUILD}",
        f"--specpath={ROOT}",
    ]

    for module in HIDDEN_IMPORTS:
        args.extend(["--hidden-import", module])

    for src, dst in add_data:
        args.extend(["--add-data", f"{src}{';' if sys.platform == 'win32' else ':'}{dst}"])

    # 排除不需要的大型模块
    excludes = [
        "tkinter",
        "IPython",
        "jupyter",
        "notebook",
        "PyQt5",
        "PySide2",
        "wx",
        "test",
        "setuptools",
    ]
    for mod in excludes:
        args.extend(["--exclude-module", mod])

    print(f"\nBuilding {APP_NAME}.exe ...")
    PyInstaller.__main__.run(args)

    exe_path = DIST / (f"{APP_NAME}.exe" if sys.platform == "win32" else APP_NAME)
    if exe_path.exists():
        size_mb = exe_path.stat().st_size / (1024 * 1024)
        print(f"\nBuild successful: {exe_path} ({size_mb:.1f} MB)")
    else:
        print(f"\nBuild may have failed — output not found at {exe_path}")
        sys.exit(1)


if __name__ == "__main__":
    if "--clean" in sys.argv:
        print("Cleaning...")
        clean()

    build()
