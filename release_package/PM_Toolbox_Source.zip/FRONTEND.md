# PM TOOLBOX — 前端开发主文档

> 本文档由 agent 读取并执行。每完成一个 Task 后，**必须**更新下方的「开发进度」表格状态，然后继续下一项。
>
> 状态约定：`TODO` → `IN_PROGRESS` → `DONE`

---

## 1. 项目概述

汽车项目管理工具箱的前端界面。深色主题（精密仪表盘风格），对接 Python FastAPI 后端（本地 127.0.0.1 服务）。

**开发环境**：家中电脑（有外网，可 npm install）
**技术栈**：React 18 + TypeScript + Vite + Tailwind CSS + shadcn/ui + Recharts + Zustand

---

## 2. 视觉规范

### 色彩系统

| Token | 值 | 用途 |
|-------|-----|------|
| bg-primary | #0a0a0c | 页面主背景 |
| bg-surface | #141416 | 卡片、面板、侧边栏 |
| text-primary | #ffffff | 标题、重要数据 |
| text-secondary | #8a8f98 | 描述、标签、次要信息 |
| accent | #d4af37 | 按钮、激活态、强调色、图表主色 |
| border | #2a2a2e | 卡片边框、分割线 |
| danger | #ff4d4d | 紧急状态、删除操作 |
| warning | #ff9f4d | 高风险、警告提示 |
| success | #4ade80 | 完成状态、正向指标 |

### 字体

```css
font-family: -apple-system, "PingFang SC", "Noto Sans SC", "Microsoft YaHei", sans-serif;
```

| 层级 | 尺寸 | 字重 | 附加 |
|------|------|------|------|
| Display | 36px | 700 | letter-spacing: -0.5px |
| H1 | 24px | 600 | — |
| H2 | 16px | 600 | — |
| Body | 13px | 400 | line-height: 1.6, color: text-secondary |
| Caption | 11px | 500 | letter-spacing: 0.5px, uppercase |
| Data | 13px | 600 | font-variant-numeric: tabular-nums |

### 间距与圆角

- 卡片圆角：`4px`（极度克制）
- 图标容器圆角：`6px`
- 按钮圆角：`4px`
- 模块间距：`32px-48px`
- 卡片内边距：`24px`
- 紧凑行间距：`12px`

### 按钮体系

**Primary**：bg-accent(#d4af37), text-[#0a0a0c], h-36px, px-24px
- Hover: brightness-110, shadow-[0_0_12px_rgba(212,175,55,0.15)]

**Secondary**：bg-transparent, border border-[#2a2a2e], text-white
- Hover: border-[#8a8f98], bg-[#1c1c1e]

**Ghost**：纯文本, text-[#8a8f98]
- Hover: text-[#d4af37]

---

## 3. 项目目录

```
src/
├── components/
│   ├── ui/                    # shadcn/ui 组件（已存在）
│   ├── LoadingScreen.tsx      # 启动加载动画
│   ├── Sidebar.tsx            # 侧边栏导航
│   └── TopBar.tsx             # 顶部状态栏
├── pages/
│   ├── Dashboard.tsx          # 造车问题追踪
│   ├── Toolbox.tsx            # 工具矩阵
│   ├── Analytics.tsx          # 数据分析看板
│   ├── FeishuMail.tsx         # 飞书邮件助手
│   └── Settings.tsx           # 环境设置
├── sections/                  # 页面区块组件
├── hooks/                     # 自定义 Hooks
├── types/
│   └── index.ts               # TypeScript 类型定义
├── stores/
│   └── appStore.ts            # Zustand 全局状态
├── services/
│   └── api.ts                 # API 封装（fetch 封装）
├── App.tsx                    # 根组件 + 路由
├── main.tsx                   # 入口（HashRouter）
└── index.css                  # 全局样式 + 自定义滚动条
```

---

## 4. 路由结构

使用 `HashRouter`，所有路由由前端处理，后端只托管静态文件。

| 路径 | 页面 | 说明 |
|------|------|------|
| / | Dashboard | 默认页面 |
| /dashboard | Dashboard | 造车问题追踪 |
| /toolbox | Toolbox | 工具矩阵 |
| /analytics | Analytics | 数据分析看板 |
| /feishu | FeishuMail | 飞书邮件助手 |
| /settings | Settings | 环境设置 |

---

## 5. 全局状态（Zustand）

```typescript
interface AppState {
  // 导航
  currentPage: string;
  isSidebarOpen: boolean;
  
  // 问题数据
  issues: Issue[];
  milestones: MilestoneProgress[];
  
  // 工具
  tools: ToolCard[];
  
  // KPI
  kpis: KpiCard[];
  
  // 统计
  departmentStats: DepartmentStats[];
  trendData: TrendPoint[];
  
  // 加载
  isLoading: boolean;
}
```

**注意**：状态管理中保留 mock 数据作为 fallback，当后端 API 不可用时显示离线提示并使用缓存数据。

---

## 6. API 调用规范

### 基础封装（services/api.ts）

```typescript
const API_BASE = '';  // 同域，FastAPI 托管前端静态文件

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: '请求失败' }));
    throw new Error(err.message);
  }
  return res.json();
}
```

### 响应格式

后端统一返回：
```json
{
  "success": true,
  "data": {},
  "message": null
}
```

前端处理：
```typescript
const result = await apiFetch('/api/issues');
if (result.success) {
  return result.data;  // 取 data 字段
} else {
  throw new Error(result.message);
}
```

### 离线检测

```typescript
// 每次 API 调用前检测后端可用性
async function checkBackend(): Promise<boolean> {
  try {
    await fetch('/api/issues?page=1&size=1', { signal: AbortSignal.timeout(3000) });
    return true;
  } catch {
    return false;
  }
}
```

---

## 7. 开发进度

> **每次完成一个 Task 后，将该行状态改为 `DONE`，并在「最后更新」记录时间。**

### Phase 1: API 封装层

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 1.1 | services/api.ts | TODO | fetch 封装：GET/POST/PUT/DELETE、统一错误处理、离线检测、超时控制 |
| 1.2 | services/api.ts — issues | TODO | issues API: getIssues(params), createIssue(data), updateIssue(id,data), deleteIssue(id), getIssueStats() |
| 1.3 | services/api.ts — excel | TODO | excel API: mergeExcel(files), mergeSameStructure(files), batchRename(folder,pattern,replacement) |
| 1.4 | services/api.ts — ppt | TODO | ppt API: getTemplates(), generateWeekly(data), generateDeliverable(data) |
| 1.5 | services/api.ts — crawler | TODO | crawler API: fetchPage(url), extractTable(url,xpath) |
| 1.6 | services/api.ts — feishu | TODO | feishu API: getMails(), syncMails(), getTodos(), toggleTodo(id) |

### Phase 2: Dashboard 页面（对接真实 API）

| Task | 文件/位置 | 状态 | 说明 |
|------|-----------|------|------|
| 2.1 | Dashboard — KPI 卡片 | TODO | 从 /api/issues/stats 获取数据替换 mock，显示加载态和错误态 |
| 2.2 | Dashboard — 数据表格 | TODO | 从 /api/issues 获取分页数据，保留现有筛选和分页交互 |
| 2.3 | Dashboard — 进度面板 | TODO | 从 /api/milestones 获取（如需后端新增此端点则记录并跳过） |
| 2.4 | Dashboard — 操作按钮 | TODO | 「新建问题单」调用 POST /api/issues、「导出周报」调用 POST /api/ppt/weekly |

### Phase 3: Toolbox 页面（对接后端）

| Task | 文件/位置 | 状态 | 说明 |
|------|-----------|------|------|
| 3.1 | Toolbox — Excel 合并 | TODO | 文件拖拽上传 → POST /api/excel/merge → 下载结果 |
| 3.2 | Toolbox — Excel 改名 | TODO | 输入文件夹路径 + 正则 → POST /api/excel/rename → 显示结果 |
| 3.3 | Toolbox — PPT 生成 | TODO | 选择模板 + 参数 → POST /api/ppt/weekly → 自动下载 |
| 3.4 | Toolbox — 爬虫工具 | TODO | 输入 URL → POST /api/crawler/fetch → 显示抓取内容 |
| 3.5 | Toolbox — 飞书同步 | TODO | 点击同步 → POST /api/feishu/sync → 刷新邮件列表 |

### Phase 4: Analytics 页面

| Task | 文件/位置 | 状态 | 说明 |
|------|-----------|------|------|
| 4.1 | Analytics — 环形图 | TODO | 从 /api/issues/stats 获取达成率数据 |
| 4.2 | Analytics — 柱状图 | TODO | 从 /api/issues/stats 获取部门关闭率 |
| 4.3 | Analytics — 面积图 | TODO | 从 /api/issues/stats 获取趋势数据 |

### Phase 5: FeishuMail 页面（对接真实 API）

| Task | 文件/位置 | 状态 | 说明 |
|------|-----------|------|------|
| 5.1 | FeishuMail — 邮件列表 | TODO | 从 /api/feishu/mails 获取，替换 mock 数据 |
| 5.2 | FeishuMail — 邮件同步 | TODO | 点击同步按钮调用 POST /api/feishu/sync |
| 5.3 | FeishuMail — 待办列表 | TODO | 从 /api/feishu/todos 获取，勾选调用 POST /api/feishu/todo-toggle |
| 5.4 | FeishuMail — AI 提醒 | TODO | 根据后端返回的预警数据动态显示 |

### Phase 6: 离线状态处理

| Task | 文件/位置 | 状态 | 说明 |
|------|-----------|------|------|
| 6.1 | components/OfflineBanner.tsx | TODO | 全局离线提示条（后端不可用时显示） |
| 6.2 | App.tsx — 离线检测 | TODO | 启动时检测后端，不可用显示 OfflineBanner |
| 6.3 | 各页面 fallback | TODO | API 失败时使用 mock 数据，不影响页面可用性 |

---

## 8. 已有代码说明

以下文件已完成初版，需要在此基础上对接 API：

| 文件 | 状态 | 说明 |
|------|------|------|
| LoadingScreen.tsx | ✅ 完成 | 启动加载动画（3个金色方块 + PM TOOLBOX 文字） |
| Sidebar.tsx | ✅ 完成 | 侧边栏导航（4个主菜单 + 设置 + 用户信息） |
| TopBar.tsx | ✅ 完成 | 面包屑 + 搜索 + 通知 + 设置图标 |
| Dashboard.tsx | 🔄 需对接 | UI 完成，数据为 mock，需替换为 API 调用 |
| Toolbox.tsx | 🔄 需对接 | UI 完成，工具卡片点击无实际功能 |
| Analytics.tsx | 🔄 需对接 | UI 完成，图表使用 mock 数据 |
| FeishuMail.tsx | 🔄 需对接 | UI 完成，邮件和待办为 mock 数据 |
| Settings.tsx | ✅ 完成 | 配置展示页面，以展示为主无需 API |
| App.tsx | 🔄 需调整 | 添加 OfflineBanner 和离线检测逻辑 |

---

## 9. 文件上传/下载处理

### Excel 合并上传

```typescript
async function uploadExcelMerge(files: File[]): Promise<string> {
  const formData = new FormData();
  files.forEach(f => formData.append('files', f));
  
  const res = await fetch('/api/excel/merge', {
    method: 'POST',
    body: formData,  // 不要设置 Content-Type，让浏览器自动设置 multipart
  });
  
  const result = await res.json();
  if (result.success) {
    // 自动下载
    window.open(`/api/download?path=${encodeURIComponent(result.data.file_path)}`);
    return result.data.file_path;
  }
  throw new Error(result.message);
}
```

### PPT 生成下载

```typescript
async function generateWeeklyPPT(params: WeeklyParams): Promise<void> {
  const res = await fetch('/api/ppt/weekly', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  
  const result = await res.json();
  if (result.success) {
    window.open(`/api/download?path=${encodeURIComponent(result.data)}`);
  }
}
```

---

## 10. 最后更新

- 创建时间：2026-05-27
- 最后更新：2026-05-27
- 当前 Phase：Phase 1（API 封装层）

---

## 11. 给 Agent 的指令

1. **读取本文件**，确认当前 Phase 和 Task 状态
2. **从第一个 `TODO` 状态的任务开始**实现
3. 每完成一个 Task：
   - 将表格中该行的 `TODO` 改为 `DONE`
   - 更新「最后更新」时间
   - 继续下一个 `TODO`
4. **优先实现 services/api.ts**（所有页面的基础依赖）
5. **已有 UI 代码不要重写**，只在其基础上添加 API 调用逻辑
6. 代码写入对应文件路径（相对于 src/ 目录）
