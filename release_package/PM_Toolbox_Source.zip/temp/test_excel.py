import pandas as pd
import requests

# Create test files
df1 = pd.DataFrame({'Name': ['Alice', 'Bob'], 'Age': [25, 30]})
df1.to_excel('test1.xlsx', index=False)

df2 = pd.DataFrame({'Name': ['Charlie', 'Dave'], 'Age': [35, 40]})
df2.to_excel('test2.xlsx', index=False)

df3 = pd.DataFrame({'ID': [1, 2], 'Value': ['A', 'B']})
df3.to_excel('test3.xlsx', index=False)

# Test merge API
url = 'http://127.0.0.1:8002/api/excel/merge'
files = [('files', open('test1.xlsx', 'rb')), ('files', open('test3.xlsx', 'rb'))]
resp = requests.post(url, files=files)
print("Merge API:", resp.json())

# Test merge-same API
url = 'http://127.0.0.1:8002/api/excel/merge-same'
files = [('files', open('test1.xlsx', 'rb')), ('files', open('test2.xlsx', 'rb'))]
resp = requests.post(url, files=files)
print("Merge-Same API:", resp.json())
