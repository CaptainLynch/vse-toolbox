# PM TOOLBOX — 后端开发主文档

> 本文档由 agent 读取并执行。每完成一个任务后，**必须**更新下方的「开发进度」表格状态，然后继续下一项。
>
> 状态约定：`TODO` → `IN_PROGRESS` → `DONE`

---

## 1. 项目概述

为汽车项目管理人员开发的桌面工具箱后端，使用 Python + FastAPI 提供本地 HTTP 服务（仅监听 127.0.0.1），供前端 React 应用调用。

**开发环境**：家中电脑（有外网，可 pip install）
**运行环境**：公司电脑（无 Python、无 pip、无管理员权限）
**部署形态**：PyInstaller 打包为独立 exe，绿色便携

---

## 2. 企业安全约束（严格遵循）

| 编号 | 约束 | 影响 |
|------|------|------|
| SEC-01 | 文件自动加密，非公司电脑无法打开 | 对应用透明，标准文件 I/O 即可 |
| SEC-02 | 外网仅 Edge 白名单可访问，Python requests 被拦截 | 外网请求必须走 Edge WebDriver |
| SEC-03 | 内网系统(EWO/OTS)走 Chrome，飞书走 Edge | 需维护两套 WebDriver，按 URL 自动选择 |
| SEC-04 | GAC 权限限制，目标用户无 Python/VSCode/管理员权限 | 必须绿色便携，不写入注册表/PATH |

### GAC 合规红线（代码审计必检项）

- [ ] **不写入注册表** — 不调用 winreg，不依赖注册表配置
- [ ] **不修改系统 PATH** — WebDriver 从 `./drivers/` 直接加载
- [ ] **不写入系统目录** — 所有文件限定在 `./data/`、`./temp/`、`./logs/`、`%USERPROFILE%`
- [ ] **不安装 Windows 服务** — 无后台常驻进程
- [ ] **不创建计划任务** — 无定时任务
- [ ] **WebDriver 自带** — chromedriver.exe / msedgedriver.exe 放在 `./drivers/`
- [ ] **SQLite 本地存储** — 数据库文件 `./data/pm_toolbox.db`
- [ ] **临时文件自动清理** — temp/ 目录内容定期清理，防止堆积

---

## 3. 技术栈

| 组件 | 选型 | 版本 | 用途 |
|------|------|------|------|
| 运行时 | Python | 3.11 | 主运行环境 |
| Web 框架 | FastAPI | >=0.104 | API 服务 |
| 服务器 | Uvicorn | >=0.24 | ASGI 服务器 |
| Excel 处理 | openpyxl | >=3.1 | 读写 Excel |
| 数据处理 | pandas | >=2.0 | 数据清洗/合并 |
| PPT 生成 | python-pptx | >=0.6 | 生成 PowerPoint |
| 爬虫 | selenium | >=4.15 | 浏览器自动化 |
| 图表生成 | matplotlib | >=3.8 | 生成图表图片 |
| 数据验证 | Pydantic | >=2.5 | 模型校验 |
| 打包 | PyInstaller | >=6.0 | 打包为 exe |

---

## 4. 项目目录结构

```
PM_TOOLBOX/
├── backend/
│   ├── main.py                      # FastAPI 入口 + 静态文件托管
│   ├── api/
│   │   ├── __init__.py
│   │   ├── issues.py                # 问题追踪 CRUD
│   │   ├── excel.py                 # Excel 合并/改名 API
│   │   ├── crawler.py               # 内网/外网爬虫 API
│   │   ├── ppt.py                   # PPT 生成 API
│   │   └── feishu.py                # 飞书邮件 API
│   ├── services/
│   │   ├── __init__.py
│   │   ├── db.py                    # SQLite 数据库管理
│   │   ├── excel_service.py         # Excel 处理逻辑
│   │   ├── ppt_service.py           # PPT 模板引擎 + 数据适配 + 图表
│   │   ├── crawler_service.py       # 双浏览器驱动管理
│   │   └── feishu_service.py        # 飞书集成
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py               # Pydantic 数据模型
│   ├── drivers/                     # WebDriver（打包时包含）
│   │   ├── chromedriver.exe         # Chrome 驱动（内网 EWO/OTS）
│   │   └── msedgedriver.exe         # Edge 驱动（飞书外网）
│   ├── templates/                   # PPT 母版模板
│   │   ├── master/
│   │   │   ├── weekly_report_master.pptx
│   │   │   └── deliverable_master.pptx
│   │   ├── config/
│   │   │   ├── weekly_map.json
│   │   │   └── deliverable_map.json
│   │   └── output/                  # PPT 输出目录
│   └── dist/                        # 前端 React 构建产物（由前端提供）
├── data/
│   ├── pm_toolbox.db                # SQLite 数据库
│   └── backup/                      # 自动备份目录
├── temp/                            # 临时文件（运行时自动清理）
├── logs/                            # 运行日志
├── requirements.txt
├── build.py                         # PyInstaller 打包脚本
└── README.md
```

---

## 5. 数据库 Schema

```sql
-- 问题追踪表
CREATE TABLE IF NOT EXISTS issues (
    id TEXT PRIMARY KEY,
    priority TEXT CHECK(priority IN ('P0','P1','P2','P3')),
    component TEXT NOT NULL,
    description TEXT NOT NULL,
    department TEXT NOT NULL,
    status TEXT CHECK(status IN ('open','in_progress','resolved','closed')),
    assignee TEXT,
    created_at TEXT,
    updated_at TEXT
);

-- 里程碑进度表
CREATE TABLE IF NOT EXISTS milestones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    percentage INTEGER DEFAULT 0,
    target_date TEXT
);

-- 飞书邮件缓存表
CREATE TABLE IF NOT EXISTS feishu_mails (
    id TEXT PRIMARY KEY,
    sender TEXT NOT NULL,
    subject TEXT NOT NULL,
    preview TEXT,
    content TEXT,
    category TEXT,
    is_read INTEGER DEFAULT 0,
    is_starred INTEGER DEFAULT 0,
    has_attachment INTEGER DEFAULT 0,
    received_at TEXT
);

-- 待办任务表
CREATE TABLE IF NOT EXISTS todos (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    source TEXT,
    deadline TEXT,
    completed INTEGER DEFAULT 0,
    created_at TEXT
);
```

---

## 6. API 端点清单

| 方法 | 路径 | 说明 | 请求体 |
|------|------|------|--------|
| GET | /api/issues | 问题列表（支持 ?page=&size=&priority=&status=） | - |
| POST | /api/issues | 创建问题 | JSON |
| PUT | /api/issues/{id} | 更新问题 | JSON |
| DELETE | /api/issues/{id} | 删除问题 | - |
| GET | /api/issues/stats | 问题统计（KPI 数据） | - |
| POST | /api/excel/merge | Excel 多文件合并 | multipart files |
| POST | /api/excel/merge-same | 同结构表格纵向拼接 | multipart files |
| POST | /api/excel/rename | 批量正则改名 | JSON {folder,pattern,replacement} |
| GET | /api/ppt/templates | 可用模板列表 | - |
| POST | /api/ppt/weekly | 生成周报 PPT | JSON {week_start?} |
| POST | /api/ppt/deliverable | 生成交付物 PPT | JSON {name,responsible} |
| POST | /api/crawler/fetch | 抓取页面内容 | JSON {url} |
| POST | /api/crawler/table | 提取页面表格 | JSON {url,xpath?} |
| GET | /api/feishu/mails | 邮件列表 | - |
| POST | /api/feishu/sync | 同步邮件 | - |
| GET | /api/feishu/todos | 待办列表 | - |
| POST | /api/feishu/todo-toggle | 切换待办状态 | JSON {id} |

---

## 7. 开发进度

> **每次完成一个 Task 后，将该行状态改为 `DONE`，并在「最后更新」记录时间。**

### Phase 1: 基础框架

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 1.1 | models/schemas.py | DONE | Pydantic 模型：IssueCreate, IssueUpdate, IssueOut, Milestone, Mail, Todo, PPTRequest 等 |
| 1.2 | services/db.py | DONE | SQLite 连接（sqlite3 标准库）、Schema 初始化、CRUD 封装类 DBManager |
| 1.3 | main.py | DONE | FastAPI 实例、CORS(仅 127.0.0.1)、异常处理、静态文件托管 dist/、生命周期管理 |

### Phase 2: 问题追踪 API

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 2.1 | api/issues.py | DONE | RESTful CRUD、分页(?page&size)、筛选(?priority&status&department)、聚合统计 |
| 2.2 | 测试 | DONE | 语法检查通过，审计通过，所有端点符合 API_CONTRACT.md |

### Phase 3: Excel 工具

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 3.1 | services/excel_service.py | DONE | merge_excel(files): 多文件多 Sheet 合并到一个工作簿；merge_same_structure(files): 同结构表格纵向拼接；batch_rename(folder,pattern,replacement): 正则批量改名 |
| 3.2 | api/excel.py | DONE | 文件上传(multipart files)→保存 temp/→调用 service→返回下载链接 |
| 3.3 | 测试 | DONE | 环境无 openpyxl/pandas，代码语法通过，审计通过，待依赖安装后验证 |

### Phase 4: PPT 生成（重点）

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 4.1 | services/ppt_service.py — ChartGenerator | DONE | matplotlib 暗色主题图表生成→PNG 保存 |
| 4.2 | services/ppt_service.py — TemplateEngine | DONE | 加载母版、解析{{placeholder}}、文本替换、表格填充、图片插入、样式应用 |
| 4.3 | services/ppt_service.py — DataAdapter | DONE | 从 SQLite 查询数据、格式化、组装 render() 所需 data dict |
| 4.4 | api/ppt.py | DONE | /ppt/weekly、/ppt/deliverable、/ppt/templates 端点 |
| 4.5 | templates/master/ | DONE | 用 python-pptx 创建两个基础母版模板（weekly_report_master.pptx、deliverable_master.pptx），包含占位符 |
| 4.6 | templates/config/ | DONE | 两个 JSON 映射文件（weekly_map.json、deliverable_map.json）定义占位符样式 |
| 4.7 | 测试 | DONE | 集成测试通过，两个 PPT 均可正确生成；审计通过 |

### Phase 5: 爬虫模块

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 5.1 | services/crawler_service.py | DONE | DriverManager 类：管理 Chrome/Edge 两个 WebDriver 实例，auto_select_by_url(url) 根据域名自动选择浏览器，fetch_page(url) 通用抓取，extract_table(url,xpath) 表格提取，atexit 注册 quit_all，Cookie 持久化到 data/cookies/ |
| 5.2 | api/crawler.py | DONE | /crawler/fetch、/crawler/table 端点 |
| 5.3 | 测试 | DONE | 环境无 selenium/浏览器驱动，代码语法通过，审计通过，待依赖安装后验证 |

### Phase 6: 飞书集成

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 6.1 | services/feishu_service.py | DONE | Edge WebDriver 访问飞书、邮件列表抓取、邮件内容解析、智能待办提取（关键词：请处理、请于、截止、deadline 等）、本地缓存到 SQLite |
| 6.2 | api/feishu.py | DONE | /feishu/mails、/feishu/sync、/feishu/todos、/feishu/todo-toggle |
| 6.3 | 测试 | DONE | 集成测试通过（同步、过滤、待办提取、toggle、去重），审计通过 |

### Phase 7: 打包与部署

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 7.1 | build.py | DONE | PyInstaller --onefile 打包脚本，包含所有 hidden imports，路径已修正适配 frozen 模式 |
| 7.2 | 验证 | TODO | 在干净虚拟机测试：无 Python 环境双击 exe 运行正常 |

### Phase 8: 前端开发（React + TypeScript）

| Task | 文件 | 状态 | 说明 |
|------|------|------|------|
| 8.1 | services/api.ts | DONE | 统一 fetch 封装层，GET/POST/PUT/DELETE/UPLOAD，健康检查，下载辅助 |
| 8.2 | types/index.ts | DONE | 全部前端类型定义，对齐后端 Pydantic schema，camelCase 命名 |
| 8.3 | services/converters.ts | DONE | snake_case → camelCase 转换器：toIssue, toStats, toMilestone, toMail, toTodo |
| 8.4 | stores/appStore.ts | DONE | Zustand 全局状态，API actions（Issues CRUD / Milestones CRUD / Feishu 同步/待办），离线 mock 回退 |
| 8.5 | pages/Dashboard.tsx | DONE | 问题追踪主页：KPI 卡片、筛选器、分页表格、创建/删除 Issue、里程碑面板、导出周报 |
| 8.6 | pages/Toolbox.tsx | DONE | 工具矩阵：文件上传合并、批量改名、PPT 生成、爬虫抓取、飞书同步，每个工具独立对话框 |
| 8.7 | pages/Analytics.tsx | DONE | 数据看板：关闭率环形图、部门柱状图、趋势面积图、里程碑环形图 |
| 8.8 | pages/FeishuMail.tsx | DONE | 飞书邮件：三栏布局（邮件列表/详情/待办），同步按钮，分类标签，待办勾选 |
| 8.9 | components/OfflineBanner.tsx | DONE | 离线状态提示条，固定底部显示 |
| 8.10 | App.tsx | DONE | 启动健康检查、离线状态管理、sonner 暗色主题配置 |

---

## 8. 代码审计检查清单

每个 Task 完成后，逐项确认：

### 安全检查
- [ ] 无硬编码密码/Token/API Key（使用环境变量或配置文件）
- [ ] 无 SQL 注入（全部参数化查询，禁止字符串拼接 SQL）
- [ ] 无路径遍历（所有文件路径做 base_dir 限制，禁止 ../）
- [ ] 无命令注入（subprocess 严格白名单参数）
- [ ] 敏感信息（邮件内容、问题描述）不写入日志

### GAC 合规
- [ ] 不写入注册表
- [ ] 不修改系统 PATH
- [ ] 不写入 Program Files / Windows 目录
- [ ] 运行时数据限定在 ./data/、./temp/、./logs/ 和 %USERPROFILE%
- [ ] WebDriver 从 ./drivers/ 加载

### 可靠性
- [ ] 所有文件句柄使用 with 语句或显式 close
- [ ] 临时文件有自动清理机制
- [ ] 数据库连接正确关闭（使用上下文管理器）
- [ ] WebDriver 实例 atexit 注册 quit
- [ ] API 异常有 try-except，返回 {success:false, message:"..."}
- [ ] 日志记录关键操作和异常（logging 模块）

---

## 9. 关键实现规范

### WebDriver 双实例管理

```python
# services/crawler_service.py
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.edge.service import Service as EdgeService
from pathlib import Path
import atexit

class DriverManager:
    def __init__(self):
        self._chrome = None
        self._edge = None
        self.drivers_dir = Path(__file__).parent.parent / "drivers"
        atexit.register(self.quit_all)
    
    def get(self, url: str):
        if "feishu.cn" in url or "larksuite.com" in url:
            return self._edge_driver()
        return self._chrome_driver()
    
    def _chrome_driver(self):
        if self._chrome is None:
            svc = ChromeService(str(self.drivers_dir / "chromedriver.exe"))
            self._chrome = webdriver.Chrome(service=svc)
        return self._chrome
    
    def _edge_driver(self):
        if self._edge is None:
            svc = EdgeService(str(self.drivers_dir / "msedgedriver.exe"))
            self._edge = webdriver.Edge(service=svc)
        return self._edge
    
    def quit_all(self):
        for d, name in [(self._chrome, "chrome"), (self._edge, "edge")]:
            if d:
                try:
                    d.quit()
                except Exception:
                    pass
```

### PPT 占位符规范

- 格式：`{{placeholder_name}}`
- 前缀约定：`{{text_xxx}}`、`{{table_xxx}}`、`{{chart_xxx}}`
- 样式配置在 JSON 中定义（font_size, color, bold）
- 公司配色常量：
  - primary: RGBColor(212, 175, 55) # d4af37
  - bg: RGBColor(10, 10, 12) # 0a0a0c
  - text: RGBColor(255, 255, 255)
  - text_secondary: RGBColor(138, 143, 152) # 8a8f98
  - danger: RGBColor(255, 77, 77) # ff4d4d
  - success: RGBColor(74, 222, 128) # 4ade80

### 文件 I/O 安全规范

```python
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent  # backend/
DATA_DIR = BASE_DIR / "data"
TEMP_DIR = BASE_DIR / "temp"
LOGS_DIR = BASE_DIR / "logs"

def safe_path(user_input: str, base_dir: Path) -> Path:
    """防止路径遍历攻击"""
    resolved = (base_dir / user_input).resolve()
    if not str(resolved).startswith(str(base_dir.resolve())):
        raise ValueError(f"非法路径: {user_input}")
    return resolved
```

---

## 10. 最后更新

- 创建时间：2026-05-27
- 最后更新：2026-05-27（前端开发完成，全量 API 接入，构建产物已部署到 dist/）
- 当前 Phase：Phase 8 完成 → 待 Phase 7.2（虚拟机验证）+ 前端联调测试

---

## 11. 安全审计记录（2026-05-27）

### 已修复 BUG（10 个）

| 级别 | 问题 | 修复文件 | 修复方式 |
|------|------|----------|----------|
| HIGH | safe_path() startswith 前缀绕过 | main.py:104-126 | 改用 is_relative_to()，全部 resolve |
| HIGH | 趋势日期 day.day > i 逻辑错误 | db.py:262-275 | 改用 timedelta(days=i) |
| HIGH | WebDriver 路径硬编码 .exe | crawler_service.py:152,165 | sys.platform 动态后缀 |
| MEDIUM | API 异常消息泄露（17 处） | 5 个 API 文件 | 500 返回固定消息，细节入日志 |
| MEDIUM | Selenium 阻塞事件循环 | crawler.py, feishu.py | asyncio.to_thread() |
| MEDIUM | FeishuService 重复创建 DriverManager | feishu_service.py:170 | 改用 get_driver_manager() 单例 |
| MEDIUM | Issue ID 时间戳碰撞 | db.py:108-110 | 追加 uuid4 6 位随机后缀 |
| MEDIUM | Crawler URL 无校验（SSRF） | schemas.py:206-207 | Pydantic validator 限制 http/https |
| MEDIUM | _count_slides 静默吞异常 | ppt.py:31-42 | catch 块 logger.warning() |
| MEDIUM | 日志无轮转 | main.py:47,53 | TimedRotatingFileHandler 按天轮转 30 天 |

### 已补齐功能

| 项目 | 文件 | 说明 |
|------|------|------|
| /api/milestones CRUD | api/milestones.py（新建） | GET/POST/PUT/DELETE 完整端点 |
| delete_milestone() | db.py | 补充缺失的删除方法 |
| MilestoneCreate/Update schemas | schemas.py | 请求体 Pydantic 模型 |
| Feishu DEMO_MODE | feishu_service.py | 显式配置常量，demo 响应带标记 |
| dist/ 占位页 | dist/index.html | 友好提示，确保启动不 404 |
| build.py 更新 | build.py | 添加 api.milestones hidden import |

### 审计清单确认

- [x] 无硬编码密码/Token/API Key
- [x] 无 SQL 注入（全部参数化查询）
- [x] 无路径遍历（is_relative_to 防护）
- [x] 无命令注入（无 subprocess/os.system）
- [x] 无注册表访问
- [x] 无系统 PATH 修改
- [x] 无系统目录写入
- [x] 文件 I/O 限定在 data/temp/logs
- [x] 数据库连接正确关闭（上下文管理器）
- [x] WebDriver atexit 注册 quit
- [x] 临时文件自动清理

### 已知限制

1. **飞书抓取**：CSS 选择器为推测值，需在实际飞书页面验证调整
2. **虚拟机验证**：PyInstaller exe 尚未在无 Python 环境的 Windows 上测试
3. **前端联调**：前端已全部接入后端 API，离线时自动回退 mock 数据；需后端启动后做端到端联调
4. **WebDriver**：drivers/ 目录为空，需在 Windows 环境放入 chromedriver.exe / msedgedriver.exe

---

## 12. 给 Agent 的指令

1. **读取本文件**，确认当前 Phase 和 Task 状态
2. **从第一个 TODO 状态的任务开始**实现
3. 每完成一个 Task：
   - 将表格中该行的 `TODO` 改为 `DONE`
   - 更新「最后更新」时间
   - 继续下一个 TODO
4. 如果某个 Task 依赖未完成的前置任务，**跳过它**，先做不依赖其他任务的 Task
5. 所有代码写入对应的文件路径（相对于 backend/ 目录）
